params <-
list(EVAL = FALSE)

## ----settings-knitr, include=FALSE--------------------------------------------
stopifnot(require(knitr))
opts_chunk$set(
  # collapse = TRUE,
  dev = "png",
  dpi = 150,
  fig.asp = 0.618,
  fig.width = 5,
  out.width = "60%",
  fig.align = "center",
  comment = NA,
  eval = if (isTRUE(exists("params"))) params$EVAL else FALSE
)

## ----install, eval=FALSE------------------------------------------------------
#  # we recommend running this is a fresh R session or restarting your current session
#  install.packages("cmdstanr", repos = c("https://mc-stan.org/r-packages/", getOption("repos")))

## ----library, message=FALSE---------------------------------------------------
#  library(cmdstanr)
#  check_cmdstan_toolchain(fix = TRUE, quiet = TRUE)
#  library(posterior)
#  library(bayesplot)
#  color_scheme_set("brightblue")

## ----check-toolchain----------------------------------------------------------
#  check_cmdstan_toolchain()

## ----install_cmdstan-1, include = FALSE---------------------------------------
#  if (!dir.exists(cmdstan_default_path())) {
#    install_cmdstan()
#  }

## ----install_cmdstan-2, eval=FALSE--------------------------------------------
#  install_cmdstan(cores = 2)

## ----set_cmdstan_path, eval=FALSE---------------------------------------------
#  set_cmdstan_path(PATH_TO_CMDSTAN)

## ----cmdstan_path-------------------------------------------------------------
#  cmdstan_path()
#  cmdstan_version()

## ----cmdstan_model------------------------------------------------------------
#  file <- file.path(cmdstan_path(), "examples", "bernoulli", "bernoulli.stan")
#  mod <- cmdstan_model(file)

## ----compile------------------------------------------------------------------
#  mod$print()

## ----exe_file-----------------------------------------------------------------
#  mod$exe_file()

## ----sample-------------------------------------------------------------------
#  # names correspond to the data block in the Stan program
#  data_list <- list(N = 10, y = c(0,1,0,0,0,0,0,0,0,1))
#  
#  fit <- mod$sample(
#    data = data_list,
#    seed = 123,
#    chains = 4,
#    parallel_chains = 4,
#    refresh = 500 # print update every 500 iters
#  )

## ----summary------------------------------------------------------------------
#  fit$summary()
#  fit$summary(variables = c("theta", "lp__"), "mean", "sd")
#  
#  # use a formula to summarize arbitrary functions, e.g. Pr(theta <= 0.5)
#  fit$summary("theta", pr_lt_half = ~ mean(. <= 0.5))

## ----draws, message=FALSE-----------------------------------------------------
#  # default is a 3-D draws_array object from the posterior package
#  # iterations x chains x variables
#  draws_arr <- fit$draws() # or format="array"
#  str(draws_arr)
#  
#  # draws x variables data frame
#  draws_df <- fit$draws(format = "df")
#  str(draws_df)
#  print(draws_df)

## ----as_draws-----------------------------------------------------------------
#  # this should be identical to draws_df created via draws(format = "df")
#  draws_df_2 <- as_draws_df(draws_arr)
#  identical(draws_df, draws_df_2)

## ----plots, message=FALSE-----------------------------------------------------
#  mcmc_hist(fit$draws("theta"))

## ----sampler_diagnostics------------------------------------------------------
#  # this is a draws_array object from the posterior package
#  str(fit$sampler_diagnostics())
#  
#  # this is a draws_df object from the posterior package
#  str(fit$sampler_diagnostics(format = "df"))

## ----diagnostic_summary-------------------------------------------------------
#  fit$diagnostic_summary()

## ----fit-with-warnings, results='hold'----------------------------------------
#  fit_with_warning <- cmdstanr_example("schools")

## ----diagnostic_summary-with-warnings-----------------------------------------
#  diagnostics <- fit_with_warning$diagnostic_summary()
#  print(diagnostics)
#  
#  # number of divergences reported in warning is the sum of the per chain values
#  sum(diagnostics$num_divergent)

## ----stanfit, eval=FALSE------------------------------------------------------
#  stanfit <- rstan::read_stan_csv(fit$output_files())

## ----optimize-----------------------------------------------------------------
#  fit_mle <- mod$optimize(data = data_list, seed = 123)
#  fit_mle$summary() # includes lp__ (log prob calculated by Stan program)
#  fit_mle$mle("theta")

## ----plot-mle, message = FALSE------------------------------------------------
#  mcmc_hist(fit$draws("theta")) +
#    vline_at(fit_mle$mle("theta"), size = 1.5)

## ----variational--------------------------------------------------------------
#  fit_vb <- mod$variational(data = data_list, seed = 123, output_samples = 4000)
#  fit_vb$summary("theta")

## ----plot-variational-1, message = FALSE, fig.cap="Posterior from MCMC"-------
#  mcmc_hist(fit$draws("theta"), binwidth = 0.025)

## ----plot-variational-2, message = FALSE, fig.cap="Posterior from variational"----
#  mcmc_hist(fit_vb$draws("theta"), binwidth = 0.025)

## ----save_object, eval=FALSE--------------------------------------------------
#  fit$save_object(file = "fit.RDS")
#  
#  # can be read back in using readRDS
#  fit2 <- readRDS("fit.RDS")

