params <-
list(EVAL = FALSE)

## ----settings-knitr, include=FALSE--------------------------------------------
stopifnot(require(knitr))
opts_chunk$set(
  # collapse = TRUE,
  dev = "png",
  dpi = 150,
  fig.asp = 0.618,
  fig.width = 5,
  out.width = "60%",
  fig.align = "center",
  comment = NA,
  eval = if (isTRUE(exists("params"))) params$EVAL else FALSE
)

## ----library, message=FALSE---------------------------------------------------
#  library(cmdstanr)
#  check_cmdstan_toolchain(fix = TRUE, quiet = TRUE)

## ----logistic-----------------------------------------------------------------
#  stan_file <- write_stan_file("
#  data {
#    int<lower=1> k;
#    int<lower=0> n;
#    matrix[n, k] X;
#    int y[n];
#  }
#  parameters {
#    vector[k] beta;
#    real alpha;
#  }
#  model {
#    # priors
#    target += std_normal_log(beta);
#    alpha ~ std_normal();
#  
#    y ~ bernoulli_logit(X * beta + alpha);
#  }
#  ")
#  mod <- cmdstan_model(stan_file)

## ----canonicalize, message=FALSE----------------------------------------------
#  mod$format(canonicalize = list("deprecations"))

## ----overwrite_file-----------------------------------------------------------
#  mod$format(
#      canonicalize = list("deprecations"),
#      overwrite_file = TRUE,
#      backup = FALSE
#  )
#  mod$print()

