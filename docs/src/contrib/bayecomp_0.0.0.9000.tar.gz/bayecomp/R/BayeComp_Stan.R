# Save this file as `R/BayeComp_Stan.R`

#' Bayesian Comparability with Stan
#'
#' @export
#' @param datalist a list of input values.
#' @param ... Arguments passed to `rstan::sampling` (e.g. iter, chains).
#' @return An object of class `stanfit` returned by `rstan::sampling`
#'

BayeComp_Stan <- function(datalist, ...) {
  out <- rstan::sampling(stanmodels$BayeComp,
                         data = datalist,
                         algorithm = "NUTS",
                         seed = 9182567, ...)
  return(out)
}